/*
Copyright © 2025 Devin B. Royal. All Rights Reserved.
*/
package com.devin.nmar;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class AppTest {
    @Test
    public void smoke() {
        App.main(new String[]{});
        assertTrue(true);
    }
}

/*
Copyright © 2025 Devin B. Royal. All Rights Reserved.
*/
